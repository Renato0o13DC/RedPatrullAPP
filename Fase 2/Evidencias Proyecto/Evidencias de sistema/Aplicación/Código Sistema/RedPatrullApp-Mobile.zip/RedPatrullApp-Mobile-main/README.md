Credenciales

Administrador
Usuario: renatox@mpuda.cl
Password: renatopuda

Conductor
Usuario: lcuevas@mpuda.cl
Password: 123456

Patrullero
Usuario: wgonzalez@mpuda.cl
Password: 123456
