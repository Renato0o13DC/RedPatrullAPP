package com.example.app_red_patrulla

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
